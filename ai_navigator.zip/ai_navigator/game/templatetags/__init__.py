# This file is required to make the templatetags directory a Python package.
